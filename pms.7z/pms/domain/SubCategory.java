package com.flp.pms.domain;

public class SubCategory
{
	//private members
	private int sub_category_id;
	private String sub_category_name;
	private Category category;

	//no argument constructor
	public SubCategory() {}
	
	//argument constructor
	public SubCategory(int sub_category_id, String sub_category_name, Category category) {
		this.sub_category_id = sub_category_id;
		this.sub_category_name = sub_category_name;
		this.category = category;
	}
	
	//public getters and setters
	public int getSub_category_id() {
		return sub_category_id;
	}
	public void setSub_category_id(int sub_category_id) {
		this.sub_category_id = sub_category_id;
	}
	public String getSub_category_name() {
		return sub_category_name;
	}
	public void setSub_category_name(String sub_category_name) {
		this.sub_category_name = sub_category_name;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "Sub_Category [sub_category_id=" + sub_category_id + ", sub_category_name=" + sub_category_name
				+ ", category=" + category + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + sub_category_id;
		result = prime * result + ((sub_category_name == null) ? 0 : sub_category_name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SubCategory other = (SubCategory) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (sub_category_id != other.sub_category_id)
			return false;
		if (sub_category_name == null) {
			if (other.sub_category_name != null)
				return false;
		} else if (!sub_category_name.equals(other.sub_category_name))
			return false;
		return true;
	}
	
	
}
